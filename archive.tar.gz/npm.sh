#!/usr/bin/env bash


### RUN /bin/bash -c "source /usr/local/bin/virtualenvwrapper.sh"

if [[ "$npm_registry_override" != "yes" ]]; then
  echo "refusing to source npm.sh script because env is not set."
  return 0;
fi


npm(){
  # make request to local server
  # local server responds with multiple files
  # for each file save them in the npm cache
  # the add the args below

  echo "running the npm override..";
  echo "running the npm patch" >&2;

  (
      set -e;

      rm -rf "$HOME/.npm-temp-cache";
      mkdir -p  "$HOME/.npm-temp-cache";
      cd  "$HOME/.npm-temp-cache"

#      nc localhost 3440 | tar -x > ores.tgz

      nc "npm_registry_server" 3440 | tar -x -O > ores-$(date +%s.%N).tgz


      for x in *; do
        echo "npm is adding this tar file to the cache: $x";
        command npm cache add "$x";
      done
  )

  local exit_code="$?"

  if [[ "$exit_code" != "0" ]]; then
    echo "warning, we might not have been able to get new cache.";
  fi


  command npm "$@" --cache-min=99999 --prefer-offline
}
